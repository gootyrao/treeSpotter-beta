package com.example.firebasething

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class TreesActivity : AppCompatActivity() {
    private lateinit var database: DatabaseReference
    private lateinit var editTreeName: EditText
    private lateinit var editTreeType: EditText
    private lateinit var buttonAddTree: Button
    private lateinit var editLeafColor: EditText
    private lateinit var editTrunkColor: EditText
    private lateinit var buttonChangeTree: Button
    private lateinit var returnToHome: Button
    private lateinit var treez: MutableList<Tree>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trees)

        //database = Firebase.database.reference
        val d = Firebase.database("https://fir-thing-855b1-default-rtdb.firebaseio.com")
        database = d.getReference("message")
        database.setValue("Hello world")
        editTreeName = findViewById(R.id.editName)
        editTreeType = findViewById(R.id.editSpecies)
        buttonAddTree = findViewById(R.id.addTreeButton)
        editLeafColor = findViewById(R.id.editLeafColor)
        editTrunkColor = findViewById(R.id.editTrunkColor)
        buttonChangeTree = findViewById(R.id.changeTreesButton)
        returnToHome = findViewById(R.id.returnToHome)

        treez = ArrayList()

        buttonAddTree.setOnClickListener {
            addTree()
        }

        buttonChangeTree.setOnClickListener {
            updateTree()
        }

        returnToHome.setOnClickListener {
            var homeScreen = Intent(applicationContext, HomeScreenActivity::class.java)
            startActivity(homeScreen)
        }

    }

    private fun addTree() {
        val name = editTreeName.text.toString().trim {it <= ' '}
        val type = editTreeType.text.toString().trim {it <= ' '}
        val leaf = editLeafColor.text.toString().trim {it <= ' '}
        val trunk = editTrunkColor.text.toString().trim {it <= ' '}
        val extras = getIntent().getExtras()
        val value = extras?.getString("Coordinates")
        val location = value

        val d = Firebase.database("https://fir-thing-855b1-default-rtdb.firebaseio.com")
        database = d.getReference("message")

        if (!TextUtils.isEmpty(name) || !TextUtils.isEmpty(leaf) ||
            !TextUtils.isEmpty(type) || !TextUtils.isEmpty(trunk)) {
            val id = database.push().key
            if (id != null) {
                Log.i("IDeez", id)
            }

            val tree = location?.let { Tree(id!!, name, type, leaf, trunk, it) }
            if (id != null) {
                //database.child("fir-thing-855b1").child(id).setValue(tree)
                database.child("users").child(id).setValue(tree)

            }

            editTreeName.setText("")
            editTreeType.setText("")
            editLeafColor.setText("")
            editTrunkColor.setText("")


            Toast.makeText(this, "Tree Added", Toast.LENGTH_SHORT).show()
        }
        else {
            Toast.makeText(this, "Please fill in all values ", Toast.LENGTH_SHORT).show()
        }


    }

    private fun updateTree() {
        val name = editTreeName.text.toString().trim {it <= ' '}
        val type = editTreeType.text.toString().trim {it <= ' '}
        val leaf = editLeafColor.text.toString().trim {it <= ' '}
        val trunk = editTrunkColor.text.toString().trim {it <= ' '}
        val extras = getIntent().getExtras()
        val value = extras?.getString("Coordinates")
        val location = value


        val d = Firebase.database("https://fir-thing-855b1-default-rtdb.firebaseio.com")
        database = d.getReference("message")

        if (!TextUtils.isEmpty(name) || !TextUtils.isEmpty(leaf) ||
            !TextUtils.isEmpty(type) || !TextUtils.isEmpty(trunk)) {
            val id = database.push().key

            val tree = location?.let { Tree(id!!, name, type, leaf, trunk, it) }
            if (id != null) {
                //database.child("fir-thing-855b1").child(id).setValue(tree)
                database.child("users").child(id).setValue(tree)
            }

            editTreeName.setText("")
            editTreeType.setText("")
            editLeafColor.setText("")
            editTrunkColor.setText("")


            Toast.makeText(this, "Tree Successfully Updated", Toast.LENGTH_SHORT).show()
        }
        else {
            Toast.makeText(this, "Please fill in all values ", Toast.LENGTH_SHORT).show()
        }
    }


}