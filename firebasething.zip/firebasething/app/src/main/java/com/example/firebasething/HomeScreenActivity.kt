package com.example.firebasething

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class HomeScreenActivity : AppCompatActivity() {

    private var titleTextView : TextView? = null
    private var homeImg : ImageView? = null
    private var addTreeButton : Button? = null
    private var localTreesButton : Button? = null
    private var changeTreesButton : Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen)

        // Setting up UI

        titleTextView = findViewById<TextView>(R.id.titleText)

        homeImg = findViewById<ImageView>(R.id.imageView2)

        addTreeButton = findViewById<Button>(R.id.addTreeButton)

        localTreesButton = findViewById<Button>(R.id.localTreesButton)

        changeTreesButton = findViewById<Button>(R.id.changeTreesButton)


        addTreeButton?.setOnClickListener {
            var addTreeIntent = Intent(applicationContext, MapsActivity::class.java)
            startActivity(addTreeIntent)
        }

        localTreesButton?.setOnClickListener {
            // TODO: Add name of maps activity in second parameter
            var localTreesIntent = Intent(applicationContext, MapsActivity::class.java)
            startActivity(localTreesIntent)
        }

        changeTreesButton?.setOnClickListener {
            var addTreeIntent = Intent(applicationContext, MapsActivity::class.java)
            startActivity(addTreeIntent)
        }

    }
}