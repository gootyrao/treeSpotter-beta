package com.example.firebasething

data class Tree(val id: String = "", val name: String = "", val type: String = "", val leafColor: String = "",
                val trunkColor: String = "", val location: String = "")
